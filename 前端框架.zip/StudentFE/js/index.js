// <script></script>里的vue代码全部放在ji包下的index.js
const app = new Vue({
    el: '#app',
    data: {
        msg: 'Hello,Vue!',
        students: [
            {
                sno: 95001, name: '刘建辉', gender: '男', birthday: '2020-02-01', mobile: '13900998877',
                email: 'wangjin@abc.com', address: '江苏省南京市溧水区宝塔路11号'
            },
            {
                sno: 95001, name: '刘建辉', gender: '男', birthday: '2020-02-01', mobile: '13900998877',
                email: 'wangjin@abc.com', address: '江苏省南京市溧水区宝塔路11号'
            },
            {
                sno: 95001, name: '刘建辉', gender: '男', birthday: '2020-02-01', mobile: '13900998877',
                email: 'wangjin@abc.com', address: '江苏省南京市溧水区宝塔路11号'
            },
            {
                sno: 95001, name: '刘建辉', gender: '男', birthday: '2020-02-01', mobile: '13900998877',
                email: 'wangjin@abc.com', address: '江苏省南京市溧水区宝塔路11号'
            },
            {
                sno: 95001, name: '刘建辉', gender: '男', birthday: '2020-02-01', mobile: '13900998877',
                email: 'wangjin@abc.com', address: '江苏省南京市溧水区宝塔路11号'
            },
            {
                sno: 95001, name: '刘建辉', gender: '男', birthday: '2020-02-01', mobile: '13900998877',
                email: 'wangjin@abc.com', address: '江苏省南京市溧水区宝塔路11号'
            },
            {
                sno: 95001, name: '刘建辉', gender: '男', birthday: '2020-02-01', mobile: '13900998877',
                email: 'wangjin@abc.com', address: '江苏省南京市溧水区宝塔路11号'
            },
            {
                sno: 95001, name: '刘建辉', gender: '男', birthday: '2020-02-01', mobile: '13900998877',
                email: 'wangjin@abc.com', address: '江苏省南京市溧水区宝塔路11号'
            },
            {
                sno: 95001, name: '刘建辉', gender: '男', birthday: '2020-02-01', mobile: '13900998877',
                email: 'wangjin@abc.com', address: '江苏省南京市溧水区宝塔路11号'
            },
            {
                sno: 95001, name: '刘建辉', gender: '男', birthday: '2020-02-01', mobile: '13900998877',
                email: 'wangjin@abc.com', address: '江苏省南京市溧水区宝塔路11号'
            },
        ],
        total: 100, //数据的总行数
        currentpage: 1, //当前所在的页
        pagesize: 10, //每页显示多少行
    }
})
