import pymysql
pymysql.install_as_MySQLdb()

# 此电脑ip地址
# 192.168.3.45